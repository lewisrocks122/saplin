<?php
session_start();
    require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Saplin Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>



</head>
<?php ?>
<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Start Bootstrap</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">
<?php
        
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

$sql = "SELECT * FROM about1";
$result = $con->query($sql);
                
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         echo $row["username"];
        if ($row ['image']== ""){
            echo "<div class='outter'>"."<img width='175' height='175' src='assets/placeholder.jpg'class='image-circle' alt='default Profile Pic'/>"."</div>";
            
        }
else
{
     echo "<div class='outter'>"."<img width='175' height='175' src='assets/".$row['image']."'class='image-circle' alt='default Profile Pic'/>"."</div>";
            
}
        echo "<br />";
        echo "</h4>"."</div>";
            
    }}
        
?>
     <!-- <div class="row">
            <div class="col-lg-12 text-center">
                <img src="assets/icon1.png" class="logo">
                <h1>Login</h1>
                <p class="lead">Complete the fields below to log in</p>
 <form class="myform"action="index.php" method="post">
            <label for="username">Username</label>
            <input name="username" type="text" class="form-control" id="username" placeholder="Username"><br />
            <label for="password">Password</label>
            <input name="password" type="password" class="form-control" id="password" placeholder="Password"><br /><br /><br />
            <input name="login"type="submit" class="form-control" id="login_btn" value="Log In "><br />
            <a href="register.php"><input type="button" class="form-control" id="register_btn" value="Register"></a>
            
            </form>  ->
                <?php /*
                if(isset($_POST['login']))
                {
                    $username=$_POST['username'];
                    $password=$_POST['password'];
                    $query="select * from user WHERE username ='$username' AND password='$password'";
                        
                        $query_run=mysqli_query($con,$query);
                        if (mysqli_num_rows($query_run)>0)
                        {
                            //valid
                            $_SESSION['username']= $username;
                            header('location:homepage.php');
                        }
                    else
                        //invalid
                echo '<script type="text/javascript"> alert("Invalid Credentials") </script>';
                }
*/?>
            </div>
                  </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

