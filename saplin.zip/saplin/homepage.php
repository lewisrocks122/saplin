<?php
session_start();
    require 'dbconfig/config.php';

?>
<!DOCTYPE html>
<html lang="en">
<link href='http://fonts.googleapis.com/css?family=Raleway:400,200' rel='stylesheet' type='text/css'>
        <link href="css/bootstrap.css" rel="stylesheet">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="apple-touch-icon" href="assets/custon_icon.png">

    <title>Saplin Home</title>

    <!-- Bootstrap Core CSS -->


    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>


</head>
<?php ?>
<body>

       <!-- Navigation -->
 <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav"> <form class="myform"action="about.php" method="post" enctype="multipart/form-data">
                    <li>
                          <input name="about_btn"type="submit" class="buttonn" id="about_btn" value="About">
                    </li>
                    <li>
                        <input name="dash_btn"type="submit" class="buttonn" id="dash_btn" value="Jump to Dashboard">
                    </li>
                    
                    <li>
                          <input name="chat_btn"type="submit" class="buttonn" id="chat_btn" value="Chat">
                    </li>
                    <li>
                        <input name="logout_btn"type="submit" class="buttonn" id="logout_btn" value="Log Out">
                    </li>
                </ul>
                </ul></form>
                <?php
                 if(isset($_POST['dash_btn']))
                    
                {
                                        header('location:homepage.php');
                 }
                
                
                if(isset($_POST['about_btn']))
                    
                {
                                        header('location:about.php');
                 }
         
                    if(isset($_POST['chat_btn']))
                    
                {
                                        header('location:chat.php');
                 }
                
                
                if(isset($_POST['logout_btn']))
                    
                {
                                        header('location:logout.php');
                 }
                ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">


        <div class="row">
            <div class="col-lg-12 text-center">
 <br />
                <?php 
                    if(isset($_POST['logout_btn'])){
                        session_destroy();
                        
                    
    header('Location: index.php');
    exit();
}
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

$sql = "SELECT * FROM about1 WHERE username ='{$_SESSION['username']}'";
$result = $con->query($sql);
                
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "    	
	    <div class='col-md-12 col-xs-12' align='center'>
            <div class='line'><img src='assets/custon_icon2.png' alt='Smiley face' height='42' width='42'></h3></div>";
            
             if ($row ['image']== ""){
            echo "<div class='outter'>"."<img width='175' height='175' src='assets/placeholder.jpg'class='image-circle' alt='default Profile Pic'/>"."</div>";
            
        }
else
{
     echo "<div class='outter'>"."<img width='175' height='175' src='assets/".$row['image']."'class='image-circle' alt='default Profile Pic'/>"."</div>";
            
}
            
           echo "</div>"."<h1>Hi ";
        
        
        
        
       echo $_SESSION['username'];
             echo "</h1>";
            echo "<div class='col-md-6 col-xs-6 follow line' align='center'>
            <h3>
                 125651 <br/> <span>FOLLOWERS</span>
            </h3>
        </div>";
        
        echo "<div class='col-md-6 col-xs-6 follow line' align='center'>
            <h3>
                 125651 <br/> <span>FOLLOWERS</span>
            </h3>
        </div>";
        
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "."Bio: &nbsp;" ;
        echo $row["bio"];
        echo "</h4>"."</div>";
        
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "."Interests: &nbsp;" ;
        echo $row["interests"];
        echo "</h4>"."</div>";
        
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "."Location: &nbsp;" ;
        echo $row["location"];
        echo "</h4>"."</div>";
        
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "."Height: &nbsp;" ;
        echo $row["height"];
        echo "</h4>"."</div>";
        
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "."Weight: &nbsp;" ;
        echo $row["weight"];
        echo "</h4>"."</div>";
        
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "."Gender: &nbsp;" ;
        echo $row["gender"];
        echo "</h4>"."</div>";
            
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "."Age: &nbsp;" ;
        echo $row["age"];
        echo "</h4>"."</div>";
            

    }
} else {
    echo "0 results";
}

    ?> 
            
            </div>
                  </div>
        <!-- /.row -->

    </div>
    	
 
    <?php
    $con->close();
                
                
    ?>

    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

