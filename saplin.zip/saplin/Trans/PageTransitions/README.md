
Page Transitions
=========

A showcase collection of various page transition effects using CSS animations.

[article on Codrops](http://tympanus.net/codrops/?p=15001)

[demo](http://tympanus.net/Development/PageTransitions/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)