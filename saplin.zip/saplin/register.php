<?php
session_start();
    require 'dbconfig/config.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="apple-touch-icon" href="assets/custon_icon.png">

    <title>Saplin Register</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        
        
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    


    <!-- Page Content -->
    <div class="container">
      <div class="login_box">
        <div class="row">
            <div class="col-lg-12 text-center">
                <img src="assets/icon1.png" class="logo">
                <h1>Sign Up</h1>
                <p class="lead">Complete the fields below to register with us</p><br /><br />
                      <div class="mini-form">
 <form class="myform"action="register.php" method="post">
            <label for="email">Email</label>
            <input name="email" type="text" class="form-control" id="email" placeholder="Email Address" required><br />
            <label for="username">Username</label>
            <input name="username" type="text" class="form-control" id="username" placeholder="Username" required><br />
            <label for="forename">Forename</label>
            <input name="forename" type="text" class="form-control" id="forname" placeholder="Forename" required><br />
            <label for="surname">Surname</label>
            <input name="surname" type="text" class="form-control" id="surname" placeholder="Surname" required><br />
            <label for="password">Password</label>
            <input name="password"type="password" class="form-control" id="password" placeholder="Password" required><br />
            <label for="cpassword">Confirm Password</label>
            <input name="cpassword" type="password" class="form-control" id="cpassword" placeholder="Confirm Password" required ><br />
     <br /><br />
            <input name="signup_btn" type="submit" class="buttonn" id="signup_btn" value="    Sign Up     "><br />
            </form> 
     <form class="myform"action="register.php" method="post">
     <input type="submit" name="login_btn" class="buttonn"id="login_btn" value="Back To Login"></form> 
     </div>
            </form> 
                
                <?php
                
                if(isset($_POST['login_btn']))
                    
                {
                                        header('location:index.php');
                 }
                if(isset($_POST['signup_btn']))
                    
                {
                   // echo '<script type="text/javascript"> alert ("Signup button Clicked") </script>';
                    $email = $_POST['email'];
                    $username = $_POST['username'];
                    $forename = $_POST ['forename'];
                    $surname = $_POST ['surname']   ; 
                    $password = md5($_POST ['password']);
                    $cpassword = $_POST ['cpassword'];

                    
                    if($password==$cpassword)
                    {
                        $query= "select * from user WHERE username='$username'";
					       $query_run = mysqli_query($con,$query);
                        
                        if(mysqli_num_rows($query_run)>0)
                        {
                           // there is already a user with the same username
						echo '<script type="text/javascript"> alert("The user already exists or you have missed fields") </script>';
                        }
                        else
                        {
                             $query= "insert into user values('$email','$username','$forename','$surname','$password')";
                             $query_run =mysqli_query($con,$query);
                            
                            if ($query_run)
                            {
                                echo '<script type="text/javascript"> alert ("User Sucessfully Registered. Login") </script>';
                                header('location:index.php');
                            }
                            else
                            {
                                echo '<script type="text/javascript"> alert ("Error!") </script>';
                            }
                        }
                    }
                }
                ?>
            </div>
                  </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

