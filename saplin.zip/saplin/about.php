<?php
session_start();
    require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="apple-touch-icon" href="assets/custon_icon.png">


    <title>Saplin About</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav"> <form class="myform"action="about.php" method="post" enctype="multipart/form-data">
                    <li>
                          <input name="about_btn"type="submit" class="buttonn" id="about_btn" value="About">
                    </li>
                    <li>
                        <input name="dash_btn"type="submit" class="buttonn" id="dash_btn" value="Jump to Dashboard">
                    </li>
                    <li>
                          <input name="chat_btn"type="submit" class="buttonn" id="chat_btn" value="Chat">
                    </li>
                    <li>
                        <input name="logout_btn"type="submit" class="buttonn" id="logout_btn" value="Log Out">
                    </li>
                </ul>
                </ul></form>
                <?php
                 if(isset($_POST['dash_btn']))
                    
                {
                                        header('location:homepage.php');
                 }
                
                
                if(isset($_POST['about_btn']))
                    
                {
                                        header('location:about.php');
                 }
                    if(isset($_POST['chat_btn']))
                    
                {
                                        header('location:chat.php');
                 }
                
                
                if(isset($_POST['logout_btn']))
                    
                {
                                        header('location:logout.php');
                 }
                ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">
                     <div class=miniform>
            <div class="col-lg-12 text-center">
                <img src="assets/icon1.png" class="logo">
                <h1>About</h1>
                <p class="lead">Now please take some time to fill out your details. <?php echo $_SESSION['username'] ?></p>
 <form class="myform"action="about.php" method="post" enctype="multipart/form-data">
     
     <label for="bio">Bio:</label>
     <textarea name="bio" class="form-control" id="bio" placeholder="Bio"></textarea><br />
    <label for="interests">Interests:</label>
     <textarea name="interests" class="form-control" id="interests" placeholder="Interests"></textarea><br />
     <label for="location">Location</label>
    <input name="location" type="text" class="form-control" id="location" placeholder="Location"><br />
                <label for="location">Height</label>
    <input name="height" type="text" class="form-control" id="height" placeholder="Height"><br />
                <label for="weight">Weight</label>
    <input name="weight" type="text" class="form-control" id="weight" placeholder="Weight"><br />
                <label for="location">Gender</label>
    <input name="gender" type="text" class="form-control" id="gender" placeholder="Gender"><br />
     
     <label for="age">Age</label>
     <select name="age" id="age" ></option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option><option value="32">32</option><option value="33">33</option><option value="34">34</option><option value="35">35</option><option value="36">36</option><option value="37">37</option><option value="38">38</option><option value="39">39</option><option value="40">40</option><option value="41">41</option><option value="42">42</option><option value="43">43</option><option value="44">44</option><option value="45">45</option><option value="46">46</option><option value="47">47</option><option value="48">48</option><option value="49">49</option><option value="50">50</option><option value="51">51</option><option value="52">52</option><option value="53">53</option><option value="54">54</option><option value="55">55</option><option value="56">56</option><option value="57">57</option><option value="58">58</option><option value="59">59</option><option value="60">60</option><option value="61">61</option><option value="62">62</option><option value="63">63</option><option value="64">64</option><option value="65">65</option><option value="66">66</option><option value="67">67</option><option value="68">68</option><option value="69">69</option><option value="70">70</option><option value="71">71</option><option value="72">72</option><option value="73">73</option><option value="74">74</option><option value="75">75</option><option value="76">76</option><option value="77">77</option><option value="78">78</option><option value="79">79</option><option value="80">80</option><option value="81">81</option><option value="82">82</option><option value="83">83</option><option value="84">84</option><option value="85">85</option><option value="86">86</option><option value="87">87</option><option value="88">88</option><option value="89">89</option><option value="90">90</option><option value="91">91</option><option value="92">92</option><option value="93">93</option><option value="94">94</option><option value="95">95</option><option value="96">96</option><option value="97">97</option><option value="98">98</option><option value="99">99</option><option value="100">100+</option></select>
            
            
            <input type="file" name="file">
            
                   <input name="form_btn"type="submit" class="form-control" id="form_btn" value="Update Details"><br />  
    
        </div></div>
            </form>  
                <?php
                if(isset($_POST['form_btn']))
                    
                {
                    
                   
                   // echo '<script type="text/javascript"> alert ("Signup button Clicked") </script>';
                    $bio = $_POST['bio'];
                    $username = $_SESSION['username'];
                    $interests = $_POST['interests'];
                    $location = $_POST['location'];
                    $height = $_POST['height'];
                    $weight = $_POST['weight'];
                    $gender = $_POST['gender'];
                    $age = $_POST['age'];
                    
                    
                    $check = mysqli_query($con,"SELECT * FROM about1 WHERE username ='{$_SESSION['username']}'");
                    if(mysqli_num_rows($check)>0){
                        
                        $sql = "UPDATE about1 SET bio = '$bio', interests ='$interests', location ='$location', height ='$height', weight ='$weight', gender ='$gender', age ='$age' WHERE username ='{$_SESSION['username']}'";
                        echo '<script type="text/javascript"> alert ("Your Info has been Updated") </script>';

                    }else{
                    
                        $sql = "INSERT INTO about1 (username, bio, interests, location, height, weight, gender, age)
                             VALUES ('$username', '$bio', '$interests', '$location','$height','$weight','$gender', '$age')"  ;
                    }
                    
                    
                    move_uploaded_file($_FILES['file']['tmp_name'], "assets/".$_FILES['file']['name']);
                    $q =mysqli_query($con,"UPDATE about1 SET image ='".$_FILES['file']['name']."' WHERE username ='".$_SESSION['username']."'");
                    
                       
                    if ($con->connect_error) {
                        die("Connection failed: " . $con->connect_error);
                    } 

                   

                    if ($con->query($sql) === TRUE) {   
                    header('location:homepage.php');
                    } else {
                        echo '<script type="text/javascript"> alert ("Error! ) </script>';
                        echo "Error: " . $sql . "<br>" . $con->error;
                    }

                    $con->close();
                    
                }
                        ?>
                

                  </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

