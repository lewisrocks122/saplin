<?php
$con= mysqli_connect("localhost","u1551404","04sep96") or die ("Unable to connect");
mysqli_select_db($con,"u1551404");
?>