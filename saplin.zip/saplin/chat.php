<?php
session_start();
    require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="apple-touch-icon" href="assets/custon_icon.png">


    <title>Saplin About</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>

       <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Conor Typing...</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav"> <form class="myform"action="about.php" method="post" enctype="multipart/form-data">
                    <li>
                          <input name="about_btn"type="submit" class="buttonn" id="about_btn" value="About">
                    </li>
                    <li>
                        <input name="dash_btn"type="submit" class="buttonn" id="dash_btn" value="Jump to Dashboard">
                    </li>
                    <li>
                          <input name="chat_btn"type="submit" class="buttonn" id="chat_btn" value="Chat">
                    </li>
                    <li>
                        <input name="logout_btn"type="submit" class="buttonn" id="logout_btn" value="Log Out">
                    </li>
                </ul>
                </ul></form>
                <?php
                 if(isset($_POST['dash_btn']))
                    
                {
                                        header('location:homepage.php');
                 }
                
                
                if(isset($_POST['about_btn']))
                    
                {
                                        header('location:about.php');
                 }
                    if(isset($_POST['chat_btn']))
                    
                {
                                        header('location:chat.php');
                 }
                
                
                if(isset($_POST['logout_btn']))
                    
                {
                                        header('location:logout.php');
                 }
                ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
        </div>
        <!-- /.container -->
    </nav>
<style type="text/css">
    body {
      padding-top: 50px;
    }
</style>
    <!-- Page Content -->
    <div class="containerr">

                <img src="assets/chat3.png" class="img-fluid" width="100%" alt="Responsive image">
        <div class="row">
                     
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

