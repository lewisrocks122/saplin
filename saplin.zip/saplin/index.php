<?php
session_start();
    require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="apple-touch-icon" href="assets/custon_icon.png">
    <meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>A Collection of Page Transitions</title>
		<link rel="shortcut icon" href="../favicon.ico"> 
		<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/multilevelmenu.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<link rel="stylesheet" type="text/css" href="css/animations.css" />
		<script src="js/modernizr.custom.js"></script>


    <title>Saplin Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>



</head>
<?php ?>
<body>

    <!-- Navigation -->

    <!-- Page Content -->
    <div class="container">
           <div class="login_box">

        <div class="row">
            <div class="col-lg-12 text-center">
                <img src="assets/apprefined.png" height="100px"class="logo">
                <h1>Login</h1>
                <p class="lead">Complete the fields below to log in</p>
                <div class=miniform>
 <form class="myform"action="index.php" method="post">
            <label for="username">Username</label>
            <input name="username" type="text" class="form-control" id="username" placeholder="Username"><br />
            <label for="password">Password</label>
            <input name="password" type="password" class="form-control" id="password" placeholder="Password"><br /><br /><br />   <input name="login"type="submit" class="buttonn" id="login_btn" value="  Log In "><br />
          <input type="submit" name="reg_btn" class="buttonn" id="reg_btn" value="Register">
     </div>  </div>
            </form>  
           <?php
            if(isset($_POST['reg_btn']))
                    
                {
                                        header('location:register.php');
                 }
            
            
                if(isset($_POST['login']))
                {
                    $username=$_POST['username'];
                    $password=$_POST['password'];
                    $query="select * from user WHERE username ='$username' AND password='$password'";
                        
                        $query_run=mysqli_query($con,$query);
                        if (mysqli_num_rows($query_run)>0)
                        {
                            //valid
                            $_SESSION['username']= $username;
                            header('location:about.php');
                        }
                    else
                        //invalid
                echo '<script type="text/javascript"> alert("Invalid Credentials") </script>';
                }
?>
            </div>
                  </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

