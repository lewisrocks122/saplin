<?php
session_start();
    require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="apple-touch-icon" href="assets/custon_icon.png">
    <meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>A Collection of Page Transitions</title>
		<meta name="description" content="A Collection of Page Transitions with CSS Animations" />
		<meta name="keywords" content="page transition, css animation, website, effect, css3, jquery" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico"> 
		<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/multilevelmenu.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<link rel="stylesheet" type="text/css" href="css/animations.css" />
		<script src="js/modernizr.custom.js"></script>


    <title>Saplin Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>



</head>
<?php ?>
<body>
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav"> <form class="myform"action="about.php" method="post" enctype="multipart/form-data">
                    <li>
                          <input name="about_btn"type="submit" class="buttonn" id="about_btn" value="About">
                    </li>
                    <li>
                        <input name="dash_btn"type="submit" class="buttonn" id="dash_btn" value="Jump to Dashboard">
                    </li>
                     <li>
                          <input name="friends_btn"type="submit" class="buttonn" id="friends_btn" value="Friends">
                    </li>
                    <li>
                          <input name="chat_btn"type="submit" class="buttonn" id="chat_btn" value="Chat">
                    </li>
                    <li>
                        <input name="logout_btn"type="submit" class="buttonn" id="logout_btn" value="Log Out">
                    </li>
                </ul>
                </ul></form>
                <?php
                 if(isset($_POST['dash_btn']))
                    
                {
                                        header('location:homepage.php');
                 }
                
                
                if(isset($_POST['about_btn']))
                    
                {
                                        header('location:about.php');
                 }
             if(isset($_POST['friends_btn']))
                    
                {
                                        header('location:friends.php');
                 }
                    if(isset($_POST['chat_btn']))
                    
                {
                                        header('location:chat.php');
                 }
                
                
                if(isset($_POST['logout_btn']))
                    
                {
                                        header('location:logout.php');
                 }
                ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Navigation -->

    <!-- Page Content -->
    <div class="container">
                <br /><br /><br /><br />

        <div class="row">
            <div class="col-lg-12 text-center">

                    

            
            


  <div class="container">


        <div class="row">
            <div class="col-lg-12 text-center">
 <br />
                <?php 
                    if(isset($_POST['logout_btn'])){
                        session_destroy();
                        
                    
    header('Location: index.php');
    exit();
}
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

$sql = "SELECT * FROM about1 WHERE username ='{$_SESSION['username']}'";
$result = $con->query($sql);
                
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "    	
	    <div class='col-md-12 col-xs-12' align='center'>
            <div class='line'><img src='assets/custon_icon2.png' alt='Smiley face' height='42' width='42'></h3></div>";
            
             if ($row ['image']== ""){
            echo "<div class='outter'>"."<img width='175' height='175' src='assets/placeholder.jpg'class='image-circle' alt='default Profile Pic'/>"."</div>";
            
        }
else
{
     echo "<div class='outter'>"."<img width='175' height='175' src='assets/".$row['image']."'class='image-circle' alt='default Profile Pic'/>"."</div>";
            
}
            
           echo "</div>"."<h1>Here are your friends ";
        
        
        
        
       echo $_SESSION['username'].":";
             echo "</h1>";
            
        
        echo "<div class='col-md-12 col-xs-12 follow line' align='center'>";
        echo "<h4> "." &nbsp;" ;
        echo $row["friends"];
        echo "</h4>"."</div>";
      
            

    }
} else {
    echo "0 results";
}

    ?> 
            
            </div>
                  </div>
        <!-- /.row -->

    </div>
    	
 
    <?php
    $con->close();
                
                
    ?>
    <?php echo $row["bio"]?> 
                

                  </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

